import React from 'react';
import Login from './components/Login';
import Navbar from './components/Navbar';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './components/Home';
import Inscriere from './components/Inscriere';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Admin from './components/Admin';
import AddBugguri from './components/AddBugguri';
import EditBugg from './components/EditBugg';

export default function App() {
    return (
      <>
       <Navbar />
       <ToastContainer />
    <BrowserRouter>
      <Routes>
      <Route exact path="/" element={<Home />} />
        <Route exact path="/login" element={<Login />} />
        <Route exact path="/inscriere" element={<Inscriere />} />
        <Route exact path="/admin" element={<Admin />} />
        <Route exact path="/admin/addbugg" element={<AddBugguri />} />
        <Route exact path="/admin/editbugg/:id" element={<EditBugg />} />
      </Routes>
    </BrowserRouter>
      </>
    );
  }

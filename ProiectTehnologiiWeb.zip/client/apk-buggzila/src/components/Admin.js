import React, { useEffect, useState } from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import CssBaseline from '@mui/material/CssBaseline';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import {  toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const theme = createTheme();

export default function Admin() {
  const [user, setUser] = useState({});
  const [bugguri, setbugguri] = useState([]);

  const fetchbugguri =async () => {
    const res = await fetch(`http://localhost:3000/buggs/all`);
        const data = await res.json();
        setbugguri(data);
  };
  useEffect(fetchbugguri, []);

  const stergebugg = (key) => {
    fetch(`http://localhost:3000/buggs/${key}`, {
      method: 'DELETE',
    })
      .then((res) => res.json())
      .then((data) => {
        console.log(data)
        fetchbugguri()
      });
  }
  return (
    
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <main>
        <Box
          sx={{
            bgcolor: 'background.paper',
            pt: 8,
            pb: 6,
          }}
        >
          <Container maxWidth="sm">
            <Typography
              component="h1"
              variant="h2"
              align="center"
              color="text.primary"
              gutterBottom
            >
              Bugguri observate de oameni
            </Typography>
          
            <Typography
              variant="h5"
              align="center"
              color="text.secondary"
              paragraph
            >
             Gestioneaza bugurile printr-o
              simpla apasare de buton
            </Typography>
          </Container>
          <Container maxWidth="xl">
            <Typography
              component="h1"
              variant="h2"
              align="left"
              color="text.primary"
              gutterBottom
            >
              Bug 1
            Error 404 - Eroarea 404 este un cod de stare HTTP care indica faptul ca serverul web nu poate gasi resursa solicitata. </Typography>
            <p>Bogdan B. - Verifică URL-ul: Asigură-te că adresa URL pe care o accesezi este corectă. Poate exista o simplă greșeală de tastare sau o modificare în structura URL-ului.</p>
             <p> Refresh la pagina: Încearcă să refreșhezi pagina (apăsând butonul de reîmprospătare a browser-ului sau folosind combinația de taste Ctrl + R sau Cmd + R).</p>
              <p>Căutare pe site: Dacă ești pe un site și navighezi prin link-uri, utilizează funcția de căutare a site-ului sau meniul de navigare pentru a găsi resursa dorită.</p>
          </Container>

          <Container maxWidth="xl">
            <Typography
              component="h1"
              variant="h2"
              align="left"
              color="text.primary"
              gutterBottom
            >
              Bug 2
            Error 508 - Eroarea 508 este un cod de stare HTTP care indică faptul că serverul web nu poate îndeplini cererea datorită unei limitări a capacității sale. </Typography>
            <p>Dumitrescu G. - Verifică Configurarea Serverului: Asigură-te că configurarea serverului este corectă și nu există conflicte în regulile de redirecționare sau de rutare.</p>
            <p>Revizuirea Codului Sursă: Dacă lucrezi la nivel de cod, verifică secțiunile de cod care se ocupă de redirecționări sau rutare pentru a te asigura că nu există bucle infinite.</p>
            <p>Dezactivează Redirecționările Temporare: Dacă utilizezi redirecționări temporare, încearcă să le dezactivezi temporar și vezi dacă aceasta rezolvă problema.</p>
          </Container>

          <Container maxWidth="xl">
            <Typography
              component="h1"
              variant="h2"
              align="left"
              color="text.primary"
              gutterBottom
            >
              Bug 3
            Error 511 - Codul de stare HTTP 511 indică faptul că clientul trebuie să se autentifice pentru a obține acces la resursă. </Typography>
            <p>Ana P. - Furnizează Datele de Autentificare Corecte: Asigură-te că furnizezi datele de autentificare corecte (de exemplu, nume de utilizator și parolă) atunci când îți este cerut.</p>
            <p>Utilizează Autentificarea HTTP Corectă: Verifică metoda de autentificare HTTP utilizată de server și asigură-te că te conformazi cu aceasta. De obicei, acest tip de eroare este asociat cu scheme de autentificare cum ar fi "Basic" sau "Digest."</p>
            <p>Actualizează Browser-ul sau Aplicația: Uneori, problemele de autentificare pot apărea din cauza unui browser sau a unei aplicații învechite. Asigură-te că utilizezi versiunea cea mai recentă a browser-ului sau aplicației.</p>
          </Container>
        </Box>
        
        <Container sx={{ py: 8 }} maxWidth="md">
          {}
          
          <Grid container spacing={4}>
            {bugguri.map((materie,i) => (
              <Grid item key={materie.id} xs={12} sm={6} md={4}>
                <Card
                  sx={{
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                  }}
                  style={{ cursor: 'pointer' }}
                  onClick={() =>{
                    window.location.href = `/admin/editbugg/${bugguri[i].id}`;
                  }}
                >
                  <CardMedia
                    component="img"
                    image="./course.jpg"
                    alt="random"
                  />
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Typography
                      gutterBottom
                      variant="h5"
                      component="h2"
                      style={{ textAlign: 'center' }}
                    >
                      {materie.name}
                    </Typography>
                    
                  </CardContent>
                </Card>
                <Button
                    onClick={()=>{stergebugg(bugguri[i].id)}}
                    >Sterge</Button>
              </Grid>
            ))}
          </Grid>
        </Container>
      </main>
    </ThemeProvider>
  );
}

const express = require('express');
const cors = require("cors");
const mysql=require("mysql2/promise");
let app = express();
app.use(express.json());
app.use(express.urlencoded({
    extended: true
}))

app.use(express.static('public'))

app.use(cors());


const sequelize = require('./database/sequelize');

let conn;

mysql.createConnection({
  user: 'root',
  password: 'Sablonul'
})
.then((connection) => {
  conn = connection
  return connection.query('CREATE DATABASE IF NOT EXISTS Buggzila')
}).then(() => {
  return conn.end();
}).catch((err) => {
  console.warn(err);
})

//const session = require("client-sessions"); packetul!!! client sesion de instalat
const client = "http://localhost:3000";
const {Utilizatori,Proiect} = require('./database/tabele');
const users = require('./routes/utilizatoriRoutes');
const buggs = require('./routes/proiecteRoutes');


const server = express();
server.use(express.urlencoded({ extended: true, }) );
server.use(express.json());



Proiect.belongsToMany(Utilizatori, {through: 'registrations'});
Utilizatori.belongsToMany(Proiect, {through: 'registrations'});

server.use(function (req, res, next) 
{
  res.header("Access-Control-Allow-Origin", client);
  res.header("Access-Control-Allow-Credentials", "true");
  res.header("Access-Control-Allow-Methods", "DELETE, PUT, GET, POST");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization"
  );
  next();
});



server.get("/create", async (req, res, next) => {
    try {
      await sequelize.sync({ force: true });
      res.status(201).json({ message: "Database created." });
    } catch (err) {
      next(err);
    }
});

const port = 3000;
app.listen(port);

server.use('/users',users);
server.use('/buggs',buggs);
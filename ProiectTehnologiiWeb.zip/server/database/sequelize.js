const {Sequelize} = require('sequelize');

const sequelize = new Sequelize({
    dialect: 'mysql',
    storage: './database/platform.db',
    define: {
		timestamps: false
	}
});

module.exports = sequelize; 
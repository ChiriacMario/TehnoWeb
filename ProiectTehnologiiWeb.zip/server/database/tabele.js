const sequelize = require('../database/sequelize');
const { DataTypes } = require('sequelize');

const Utilizatori = sequelize.define('utilizatori', {
    cnp: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
      },
    numele: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      prenumele: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      email: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          isEmail: { error: 'Trebuie sa fie o adresa de email valida!' },
        },
        parola: {
            type: DataTypes.STRING,
            allowNull: false
        }
}
})

const Proiect = sequelize.define('proiect', {
  id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    nume: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
          notNull: { error: 'Proiectul trebuie sa aibe un nume!' },
          notEmpty: { error: 'Numele trebuie sa contina mai multe caractere!' },
      }
    },
    continut:{
      type:DataTypes.TEXT
    }
});
module.exports = {Utilizatori,Proiect};
const autentificareUser= async (req, res, next) => {
    const { password: password, id } = req.session;
    if (!password || !id) {
      res.status(403).send({ message: "User nu e logat." });
    } else {
            next();    
      }
  };

module.exports = {autentificareUser};
const { Utilizatori,Proiect } = require("../database/tabele");
const express = require('express');
const { autentificareUser } = require("./autentificareUser");
const app = express();

app.get('/all', async (req, res, next) => {
    try {
      const proiecte = await Proiect.findAll();
      res.status(200).json(courses);
    } catch (err) {
      next(err);
    }
});

app.get('/mine',autentificareUser,async (req, res, next) => {
  try {
    const user = await Utilizatori.findByPk(req.session.cnp);
      if (user) {
        const proiecte =  await  user.getCourses(); 
        if(proiecte && proiecte.length>0){
          res.json(proiecte);
        }
        else res.status(204).json({ message: "Nu sunt proiecte." });
      } else res.status(404).json({ message: "Nimeni nu e logat." });
  } catch (err) {
    next(err);
  }
}); 

app.get('/:userId',async (req, res, next) => {
    try {
      const user = await Utilizatori.findByPk(req.params.cnp);
        if (user) {
          const courses =  await  user.getCourses(); 
          if(courses && courses.length>0){
            res.json(courses);
          }
          else res.status(204).json({ message: "Nu sunt cursuri." });
        } else res.status(404).json({ message: "Nimeni nu e logat." });
    } catch (err) {
      next(err);
    }
  }); 

  app.post("/", async (req, res, next) => {
    try {
      if(req.body.nume  && req.body.continut)
      {
        await Proiect.create(req.body);
        res.status(201).json({ message: "Proiect creat!" });
      } else {
        res.status(400).json({ message: "Eroare sintaxa!" });
      }
    } catch (err) {
      next(err);
    }
  });

  app.get('/get/:ProiectId', async (req, res, next) => {
    try {
      const pr = await Proiect.findByPk(req.params.ProiectId);
      if(course){
        res.status(200).json(pr);
      } else {
        res.status(404).json({ message: "Proiect de negasit!" });
      }
    } catch (err) {
      next(err);
    }
  });

  app.put("/:ProiectId", async (req, res, next) => {
    try {
      const course = await Proiect.findByPk(req.params.ProiectIdId);
      if(course){
        if( req.body.nume && req.body.continut){
          await course.update(req.body);
          res.status(201).json({ message: "Updateul e gata." });
        } else {
          res.status(400).json({ message: "Eroare!" });
        }
      } else {
        res.status(404).json({ message: "Curs de negasit!" });
      }
    } catch (err) {
      next(err);
    }
  });

  app.delete("/:ProiectId", async (req, res, next) => {
    try {
      const proiectulul = await Proiect.findByPk(req.params.ProiectId);
      if(course){
       await proiectulul.destroy();
          res.status(202).json({ message: "Proiectul a disparut!" });
      } else {
        res.status(404).json({ message: "Proiectul nu a fost gasit!" });
      }
    } catch (err) {
      next(err);
    }
  });

  app.post("/register/:ProiectId", autentificareUser,async (req, res, next) => {
    try {
      const course = await Proiect.findByPk(req.params.ProiectId);
      if(!course) res.status(404).json({ message: "Curs de negasit!" });
      const user = await Utilizatori.findByPk(req.session.cnp);
      if(!user) res.status(404).json({ message: "Utilizator de negasit!" });
      user.addCourse(course);
      await user.save();
      res.status(200).json({ message: `Utilizator ${req.session.id} registrat pentru cursul ${req.params.ProiectId}` });
    } catch (err) {
      next(err);
    }
  });

  app.post("/register/:courseId/users/:userId",async (req, res, next) => {
    try {
      const course = await Proiect.findByPk(req.params.courseId);
      if(!course) res.status(404).json({ message: "Curs negasit!!" });
      const user = await Utilizatori.findByPk(req.params.userId);
      if(!user) res.status(404).json({ message: "Utilizator negasit!" });
      user.addCourse(course);
      await user.save();
      res.status(200).json({ message: `User ${req.params.userId} registered for course ${req.params.courseId}` });
    } catch (err) {
      next(err);
    }
  });

  app.delete("/unregister/:courseId",autentificareUser, async (req, res, next) => {
    try {
      const course = await Proiect.findByPk(req.params.courseId);
      if(!course) res.status(404).json({ message: "Curs negasit!!!" });
      const user = await Utilizatori.findByPk(req.session.cnp);
      if(!user) res.status(404).json({ message: "Utilizator negasit!" });
      if(await user.hasCourse(course)){
        user.removeCourse(course);
        await user.save();
        res.status(200).json({ message: `Utilizator ${req.session.cnp} scos de la proiectul ${req.params.courseId}` });
      } else res.status(404).json({ message: "Utilizatorul nu are in gestiune proiectul asta!" });
    } catch (err) {
      next(err);
    }
  });

module.exports=app;
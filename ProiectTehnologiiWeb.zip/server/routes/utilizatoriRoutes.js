const {Utilizatori, Proiect} = require("../database/tabele");
const express = require('express');
const app = express();

app.get('/', async (req, res, next) => {
    try {
      const utilizatori = await User.findAll();
      res.status(200).json(utilizatori);
    } catch (err) {
      next(err);
    }
});

app.post("/", async (req, res, next) => {
    try {
      if(req.body.numele && req.body.prenumele && req.body.email && req.body.parola){
        await Utilizatori.create(req.body);
        res.status(201).json({ message: "Utilizator creat!" });
      } else {
        res.status(400).json({ message: "Date incomplete!" });
      }
    } catch (err) {
      next(err);
    }
  });

  app.get('/:userCnp', async (req, res, next) => {
    try {
      const user = await Utilizatori.findByPk(req.params.userCnp);
      if(user){
        res.status(200).json(user);
      } else {
        res.status(404).json({ message: "Utilizator negasit" });
      }
    } catch (err) {
      next(err);
    }
  });

  app.put("/:userCnp", async (req, res, next) => {
    try {
      const user = await User.findByPk(req.params.userCnp);
      if(user){
        if(req.body.cnp && req.body.numele && req.body.prenumele && req.body.email && req.body.parola){
          await user.update(req.body);
          res.status(201).json({ message: "Updateul este gata." });
        } else {
          res.status(400).json({ message: "Ceva nu a mers bine!" });
        }
      } else {
        res.status(404).json({ message: "Utilizator negasit!" });
      }
    } catch (err) {
      next(err);
    }
  });

  app.delete("/:proiectId", async (req, res, next) => {
    try {
      const proiectul = await Proiect.findByPk(req.params.proiectId);
      if(proiectul){
       await proiectul.destroy();
          res.status(202).json({ message: "Proiectul a disparut!" });
      } else {
        res.status(404).json({ message: "Proiect de negasit!" });
      }
    } catch (err) {
      next(err);
    }
  });

  app.get("/auth/logout", async (req, res) => {
    if(req.session.cnp&& req.session.parola){
      req.session.reset();
      res.status(200).send({ message: "Te-ai logat." });
    } else res.status(404).send({ message: "Nimeni nu e logat." });
  });

  app.get("/auth/logged", async (req, res) => {
    if(req.session.cnp&& req.session.parola){
      let user = await Utilizatori.findByPk(req.session.cnp);
      res.status(200).json(user);
    } else res.status(404).send({ message: "Nimeni nu e logat." });
  });

  app.post("/auth/login", async (req, res) => {
    const { email, parola } = req.body;
    const user = await Utilizatori.findOne({ where: { email, parola } });
    if (!user) {
      res.status(403).send({ message: "Ups... A aparut o eroare!" });
    } else {
        if(req.session.cnp) res.status(403).send({ message: "Iesi inainte de a intra." });
       else {
        req.session.cnp = user.cnp;
        req.session.parola = user.parola;
        req.session.email=user.email
        res.status(200).json({ id: user.cnp });
      }
    }
  });

  module.exports = app;

  